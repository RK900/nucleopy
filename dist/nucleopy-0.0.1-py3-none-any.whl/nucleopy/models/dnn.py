'''
Creates a deep neural network
'''

# import tensorflow as tf
# import numpy as np
# import os, math
# from cnn import CNN
#
#
# class DNN(CNN):
#     def __init__(self, X, y, test_X, test_y, numfeatures, featuresize, numclasses,
#                  layers, nodes, epochs, activation, learningrate=0.001,
#                  optimizer="adam", dropout=0.1, batchsize=100, path=os.getcwd()+'/models/', name='DNN'):
#         super(X, y, test_X, test_y, numfeatures, featuresize, numclasses, epochs,
#               activation, learningrate, optimizer, dropout, batchsize, path, name)
#         self.layers = layers
#         self.nodes = nodes
#
#     def __build(self):
#         weights_keys = []
#         weights_values = []
